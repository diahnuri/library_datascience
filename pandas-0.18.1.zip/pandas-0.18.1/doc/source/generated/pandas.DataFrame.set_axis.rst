pandas.DataFrame.set_axis
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.set_axis