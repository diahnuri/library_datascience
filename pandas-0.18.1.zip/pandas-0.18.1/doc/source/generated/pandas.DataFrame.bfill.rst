pandas.DataFrame.bfill
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.bfill