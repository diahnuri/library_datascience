pandas.core.window.Expanding.count
==================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.count