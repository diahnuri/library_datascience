pandas.DataFrame.T
==================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.T