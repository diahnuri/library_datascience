pandas.CategoricalIndex.view
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.view