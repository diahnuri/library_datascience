pandas.CategoricalIndex.argmin
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.argmin