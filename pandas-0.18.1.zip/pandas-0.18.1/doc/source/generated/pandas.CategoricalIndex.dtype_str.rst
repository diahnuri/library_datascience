pandas.CategoricalIndex.dtype_str
=================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.dtype_str