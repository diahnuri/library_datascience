pandas.CategoricalIndex.rename_categories
=========================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.rename_categories