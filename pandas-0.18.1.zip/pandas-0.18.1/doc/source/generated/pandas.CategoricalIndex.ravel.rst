pandas.CategoricalIndex.ravel
=============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.ravel