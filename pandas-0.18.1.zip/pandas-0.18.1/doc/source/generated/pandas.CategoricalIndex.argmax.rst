pandas.CategoricalIndex.argmax
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.argmax