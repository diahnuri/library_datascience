pandas.DataFrame.isin
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.isin