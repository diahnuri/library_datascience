pandas.CategoricalIndex.sort_values
===================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.sort_values