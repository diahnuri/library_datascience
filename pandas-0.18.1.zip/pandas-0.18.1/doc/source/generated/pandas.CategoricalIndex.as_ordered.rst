pandas.CategoricalIndex.as_ordered
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.as_ordered