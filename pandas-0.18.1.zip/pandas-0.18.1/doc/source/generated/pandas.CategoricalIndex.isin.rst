pandas.CategoricalIndex.isin
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.isin