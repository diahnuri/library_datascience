pandas.DataFrame.select_dtypes
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.select_dtypes