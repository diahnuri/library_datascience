pandas.DataFrame.asfreq
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.asfreq