pandas.core.groupby.DataFrameGroupBy.mad
========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.mad