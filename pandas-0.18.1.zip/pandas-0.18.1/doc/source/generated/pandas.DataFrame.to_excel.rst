pandas.DataFrame.to_excel
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_excel