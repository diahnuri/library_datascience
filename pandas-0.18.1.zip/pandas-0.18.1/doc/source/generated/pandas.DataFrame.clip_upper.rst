pandas.DataFrame.clip_upper
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.clip_upper