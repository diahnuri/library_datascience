pandas.core.groupby.DataFrameGroupBy.size
=========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.size