pandas.DataFrame.subtract
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.subtract