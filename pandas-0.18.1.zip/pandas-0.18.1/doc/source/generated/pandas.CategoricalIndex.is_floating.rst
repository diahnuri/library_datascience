pandas.CategoricalIndex.is_floating
===================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_floating