pandas.core.groupby.DataFrameGroupBy.resample
=============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.resample