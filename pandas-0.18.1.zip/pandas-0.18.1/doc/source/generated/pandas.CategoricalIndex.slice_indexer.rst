pandas.CategoricalIndex.slice_indexer
=====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.slice_indexer