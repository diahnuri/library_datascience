pandas.DataFrame.plot.pie
=========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.pie