pandas.DataFrame.tail
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.tail