pandas.CategoricalIndex.name
============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.name