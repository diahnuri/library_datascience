pandas.DataFrame.cumsum
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.cumsum