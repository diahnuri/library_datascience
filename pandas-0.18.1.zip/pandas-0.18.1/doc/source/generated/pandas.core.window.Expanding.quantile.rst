pandas.core.window.Expanding.quantile
=====================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.quantile