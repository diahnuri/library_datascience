pandas.CategoricalIndex.drop
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.drop