pandas.CategoricalIndex.min
===========================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.min