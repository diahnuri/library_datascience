pandas.CategoricalIndex.remove_unused_categories
================================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.remove_unused_categories