pandas.core.groupby.GroupBy.std
===============================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.std