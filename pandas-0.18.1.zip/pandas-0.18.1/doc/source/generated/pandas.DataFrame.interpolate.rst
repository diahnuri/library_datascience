pandas.DataFrame.interpolate
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.interpolate