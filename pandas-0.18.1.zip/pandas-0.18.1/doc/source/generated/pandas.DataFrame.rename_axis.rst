pandas.DataFrame.rename_axis
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.rename_axis