pandas.DataFrame.get_dtype_counts
=================================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_dtype_counts