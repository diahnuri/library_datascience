pandas.CategoricalIndex.get_duplicates
======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_duplicates