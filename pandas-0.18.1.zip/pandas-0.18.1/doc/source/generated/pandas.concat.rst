pandas.concat
=============

.. currentmodule:: pandas

.. autofunction:: concat