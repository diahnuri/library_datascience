pandas.CategoricalIndex.add_categories
======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.add_categories