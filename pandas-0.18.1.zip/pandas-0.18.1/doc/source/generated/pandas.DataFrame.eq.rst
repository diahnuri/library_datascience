pandas.DataFrame.eq
===================

.. currentmodule:: pandas

.. automethod:: DataFrame.eq