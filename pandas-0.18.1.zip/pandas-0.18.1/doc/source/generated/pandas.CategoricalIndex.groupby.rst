pandas.CategoricalIndex.groupby
===============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.groupby