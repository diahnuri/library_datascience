pandas.core.groupby.SeriesGroupBy.value_counts
==============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: SeriesGroupBy.value_counts