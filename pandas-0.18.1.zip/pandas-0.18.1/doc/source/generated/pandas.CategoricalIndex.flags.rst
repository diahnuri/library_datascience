pandas.CategoricalIndex.flags
=============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.flags