pandas.DataFrame.mod
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.mod