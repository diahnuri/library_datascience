pandas.core.groupby.GroupBy.__iter__
====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.__iter__