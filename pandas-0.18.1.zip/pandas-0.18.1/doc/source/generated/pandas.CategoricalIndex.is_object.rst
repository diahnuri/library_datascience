pandas.CategoricalIndex.is_object
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_object