pandas.DataFrame.any
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.any