pandas.DataFrame.empty
======================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.empty