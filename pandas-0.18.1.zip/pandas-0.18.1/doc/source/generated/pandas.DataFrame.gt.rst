pandas.DataFrame.gt
===================

.. currentmodule:: pandas

.. automethod:: DataFrame.gt