pandas.core.window.Rolling.mean
===============================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.mean