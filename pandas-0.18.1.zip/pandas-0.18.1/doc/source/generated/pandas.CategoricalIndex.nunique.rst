pandas.CategoricalIndex.nunique
===============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.nunique