pandas.DataFrame.mad
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.mad