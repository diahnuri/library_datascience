pandas.DataFrame.sub
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.sub