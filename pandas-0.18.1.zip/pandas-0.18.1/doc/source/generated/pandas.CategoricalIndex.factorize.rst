pandas.CategoricalIndex.factorize
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.factorize