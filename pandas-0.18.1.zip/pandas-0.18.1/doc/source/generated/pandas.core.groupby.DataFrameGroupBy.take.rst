pandas.core.groupby.DataFrameGroupBy.take
=========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.take