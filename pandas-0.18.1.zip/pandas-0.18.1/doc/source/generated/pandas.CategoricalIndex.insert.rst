pandas.CategoricalIndex.insert
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.insert