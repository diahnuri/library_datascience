pandas.DataFrame.pow
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.pow