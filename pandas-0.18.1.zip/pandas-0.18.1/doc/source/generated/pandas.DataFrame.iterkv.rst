pandas.DataFrame.iterkv
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.iterkv