pandas.core.groupby.GroupBy.groups
==================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: GroupBy.groups