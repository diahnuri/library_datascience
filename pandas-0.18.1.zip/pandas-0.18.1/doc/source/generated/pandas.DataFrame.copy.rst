pandas.DataFrame.copy
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.copy