pandas.CategoricalIndex.is_monotonic_increasing
===============================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.is_monotonic_increasing