pandas.crosstab
===============

.. currentmodule:: pandas

.. autofunction:: crosstab