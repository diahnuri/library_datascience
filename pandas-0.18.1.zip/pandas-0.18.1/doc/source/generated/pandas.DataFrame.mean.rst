pandas.DataFrame.mean
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.mean