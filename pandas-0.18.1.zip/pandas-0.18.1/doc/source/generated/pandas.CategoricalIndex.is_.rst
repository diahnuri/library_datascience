pandas.CategoricalIndex.is_
===========================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_