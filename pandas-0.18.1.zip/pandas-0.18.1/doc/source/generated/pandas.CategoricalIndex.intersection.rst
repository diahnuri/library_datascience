pandas.CategoricalIndex.intersection
====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.intersection