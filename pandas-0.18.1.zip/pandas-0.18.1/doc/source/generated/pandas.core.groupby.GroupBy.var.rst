pandas.core.groupby.GroupBy.var
===============================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.var