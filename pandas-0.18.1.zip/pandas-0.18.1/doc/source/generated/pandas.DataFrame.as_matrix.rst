pandas.DataFrame.as_matrix
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.as_matrix