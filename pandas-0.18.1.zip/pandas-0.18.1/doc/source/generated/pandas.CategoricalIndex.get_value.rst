pandas.CategoricalIndex.get_value
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_value