pandas.DataFrame.sortlevel
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.sortlevel