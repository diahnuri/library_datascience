pandas.CategoricalIndex.is_numeric
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_numeric