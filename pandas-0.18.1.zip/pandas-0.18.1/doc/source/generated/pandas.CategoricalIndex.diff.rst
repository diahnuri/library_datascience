pandas.CategoricalIndex.diff
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.diff