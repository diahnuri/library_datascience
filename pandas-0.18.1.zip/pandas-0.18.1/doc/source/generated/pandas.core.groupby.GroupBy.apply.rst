pandas.core.groupby.GroupBy.apply
=================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.apply