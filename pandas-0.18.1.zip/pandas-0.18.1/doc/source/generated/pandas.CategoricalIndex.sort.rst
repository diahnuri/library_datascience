pandas.CategoricalIndex.sort
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.sort