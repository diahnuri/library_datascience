pandas.core.window.Rolling.cov
==============================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.cov