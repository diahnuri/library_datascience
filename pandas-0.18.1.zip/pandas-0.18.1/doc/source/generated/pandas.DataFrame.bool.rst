pandas.DataFrame.bool
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.bool