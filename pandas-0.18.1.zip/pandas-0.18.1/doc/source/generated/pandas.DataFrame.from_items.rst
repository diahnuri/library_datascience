pandas.DataFrame.from_items
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_items