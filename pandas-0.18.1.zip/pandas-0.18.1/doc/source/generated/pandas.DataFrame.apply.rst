pandas.DataFrame.apply
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.apply