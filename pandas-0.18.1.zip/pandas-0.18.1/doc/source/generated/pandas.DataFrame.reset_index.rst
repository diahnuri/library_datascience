pandas.DataFrame.reset_index
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.reset_index