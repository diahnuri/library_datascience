pandas.CategoricalIndex.is_boolean
==================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_boolean