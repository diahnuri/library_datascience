pandas.CategoricalIndex.value_counts
====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.value_counts