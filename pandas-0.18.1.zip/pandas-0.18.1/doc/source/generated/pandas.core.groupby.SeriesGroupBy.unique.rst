pandas.core.groupby.SeriesGroupBy.unique
========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: SeriesGroupBy.unique