pandas.core.groupby.GroupBy.indices
===================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: GroupBy.indices