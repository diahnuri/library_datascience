pandas.DataFrame.first_valid_index
==================================

.. currentmodule:: pandas

.. automethod:: DataFrame.first_valid_index