pandas.DataFrame.from_records
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_records