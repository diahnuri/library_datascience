pandas.core.groupby.DataFrameGroupBy.boxplot
============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.boxplot