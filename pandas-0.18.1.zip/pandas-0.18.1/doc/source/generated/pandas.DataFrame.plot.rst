pandas.DataFrame.plot
=====================

.. currentmodule:: pandas

.. autoaccessorcallable:: DataFrame.plot.__call__