pandas.DataFrame.isnull
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.isnull