pandas.CategoricalIndex.itemsize
================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.itemsize