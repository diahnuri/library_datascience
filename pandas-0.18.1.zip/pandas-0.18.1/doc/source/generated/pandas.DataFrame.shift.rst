pandas.DataFrame.shift
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.shift