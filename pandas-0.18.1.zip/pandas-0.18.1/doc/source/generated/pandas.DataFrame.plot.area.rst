pandas.DataFrame.plot.area
==========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.area