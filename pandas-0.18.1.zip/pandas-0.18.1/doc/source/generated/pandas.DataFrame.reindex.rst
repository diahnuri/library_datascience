pandas.DataFrame.reindex
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.reindex