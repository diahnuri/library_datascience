pandas.DataFrame.blocks
=======================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.blocks