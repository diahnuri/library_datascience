pandas.CategoricalIndex.get_indexer
===================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_indexer