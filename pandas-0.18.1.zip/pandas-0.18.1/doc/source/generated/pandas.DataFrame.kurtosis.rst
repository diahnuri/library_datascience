pandas.DataFrame.kurtosis
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.kurtosis