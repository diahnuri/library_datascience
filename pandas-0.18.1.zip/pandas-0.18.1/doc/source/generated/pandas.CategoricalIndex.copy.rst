pandas.CategoricalIndex.copy
============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.copy