pandas.DataFrame.drop_duplicates
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.drop_duplicates