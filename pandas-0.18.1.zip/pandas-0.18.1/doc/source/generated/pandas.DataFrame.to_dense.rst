pandas.DataFrame.to_dense
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_dense