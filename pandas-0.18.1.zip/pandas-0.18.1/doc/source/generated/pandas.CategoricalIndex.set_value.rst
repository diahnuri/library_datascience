pandas.CategoricalIndex.set_value
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.set_value