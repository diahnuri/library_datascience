pandas.core.groupby.DataFrameGroupBy.cummax
===========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.cummax