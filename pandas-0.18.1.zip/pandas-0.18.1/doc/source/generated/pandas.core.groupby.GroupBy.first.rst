pandas.core.groupby.GroupBy.first
=================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.first