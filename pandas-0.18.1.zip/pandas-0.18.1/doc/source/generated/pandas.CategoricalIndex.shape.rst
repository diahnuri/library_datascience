pandas.CategoricalIndex.shape
=============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.shape