pandas.core.window.Rolling.apply
================================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.apply