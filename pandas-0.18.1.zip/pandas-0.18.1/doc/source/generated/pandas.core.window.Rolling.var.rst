pandas.core.window.Rolling.var
==============================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.var