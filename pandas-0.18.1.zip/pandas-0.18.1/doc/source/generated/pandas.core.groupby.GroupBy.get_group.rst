pandas.core.groupby.GroupBy.get_group
=====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.get_group