pandas.DataFrame.cummax
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.cummax