pandas.core.window.Rolling.skew
===============================

.. currentmodule:: pandas.core.window

.. automethod:: Rolling.skew