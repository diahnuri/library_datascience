pandas.DataFrame.div
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.div