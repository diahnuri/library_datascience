pandas.CategoricalIndex.size
============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.size