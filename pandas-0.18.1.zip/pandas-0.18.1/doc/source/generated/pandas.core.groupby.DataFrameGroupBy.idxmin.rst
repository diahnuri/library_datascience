pandas.core.groupby.DataFrameGroupBy.idxmin
===========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.idxmin