pandas.CategoricalIndex.get_indexer_for
=======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.get_indexer_for