pandas.CategoricalIndex.putmask
===============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.putmask