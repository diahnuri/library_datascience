pandas.DataFrame.align
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.align