pandas.DataFrame.info
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.info