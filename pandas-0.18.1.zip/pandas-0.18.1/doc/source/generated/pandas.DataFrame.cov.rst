pandas.DataFrame.cov
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.cov