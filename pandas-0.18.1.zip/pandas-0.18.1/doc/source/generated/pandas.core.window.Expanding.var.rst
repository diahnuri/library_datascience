pandas.core.window.Expanding.var
================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.var