pandas.CategoricalIndex.symmetric_difference
============================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.symmetric_difference