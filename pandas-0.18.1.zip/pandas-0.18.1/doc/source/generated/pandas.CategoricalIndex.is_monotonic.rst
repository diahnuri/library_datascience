pandas.CategoricalIndex.is_monotonic
====================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.is_monotonic