pandas.CategoricalIndex.is_categorical
======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.is_categorical