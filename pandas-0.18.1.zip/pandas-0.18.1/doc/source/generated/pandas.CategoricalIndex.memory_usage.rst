pandas.CategoricalIndex.memory_usage
====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.memory_usage