pandas.core.groupby.SeriesGroupBy.nsmallest
===========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: SeriesGroupBy.nsmallest