pandas.DataFrame.__iter__
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.__iter__