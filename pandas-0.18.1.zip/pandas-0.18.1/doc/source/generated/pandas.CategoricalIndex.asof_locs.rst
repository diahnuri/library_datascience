pandas.CategoricalIndex.asof_locs
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.asof_locs