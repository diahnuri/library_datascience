pandas.CategoricalIndex.identical
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.identical