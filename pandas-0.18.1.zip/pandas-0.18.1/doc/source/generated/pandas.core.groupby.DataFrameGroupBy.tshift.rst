pandas.core.groupby.DataFrameGroupBy.tshift
===========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.tshift