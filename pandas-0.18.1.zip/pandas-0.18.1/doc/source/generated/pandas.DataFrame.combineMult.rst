pandas.DataFrame.combineMult
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.combineMult