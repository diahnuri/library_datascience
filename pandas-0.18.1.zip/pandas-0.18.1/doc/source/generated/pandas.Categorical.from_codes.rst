pandas.Categorical.from_codes
=============================

.. currentmodule:: pandas

.. automethod:: Categorical.from_codes