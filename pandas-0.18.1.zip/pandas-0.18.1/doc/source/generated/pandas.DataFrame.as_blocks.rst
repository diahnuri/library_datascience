pandas.DataFrame.as_blocks
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.as_blocks