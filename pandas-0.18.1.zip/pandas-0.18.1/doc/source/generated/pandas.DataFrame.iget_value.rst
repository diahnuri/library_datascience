pandas.DataFrame.iget_value
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.iget_value