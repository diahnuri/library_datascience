pandas.CategoricalIndex.to_native_types
=======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.to_native_types