pandas.DataFrame.std
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.std