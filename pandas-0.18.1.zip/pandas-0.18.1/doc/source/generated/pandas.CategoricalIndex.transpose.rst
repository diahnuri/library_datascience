pandas.CategoricalIndex.transpose
=================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.transpose