pandas.CategoricalIndex.astype
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.astype