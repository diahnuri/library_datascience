pandas.DataFrame.join
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.join