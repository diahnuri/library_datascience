pandas.core.groupby.GroupBy.aggregate
=====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.aggregate