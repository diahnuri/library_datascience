pandas.core.groupby.GroupBy.median
==================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.median