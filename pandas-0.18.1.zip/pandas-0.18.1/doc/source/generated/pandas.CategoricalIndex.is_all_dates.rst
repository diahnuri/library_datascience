pandas.CategoricalIndex.is_all_dates
====================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.is_all_dates