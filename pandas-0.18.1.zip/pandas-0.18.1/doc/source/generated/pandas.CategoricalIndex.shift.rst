pandas.CategoricalIndex.shift
=============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.shift