pandas.DataFrame.sort_values
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.sort_values