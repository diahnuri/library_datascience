pandas.DataFrame.irow
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.irow