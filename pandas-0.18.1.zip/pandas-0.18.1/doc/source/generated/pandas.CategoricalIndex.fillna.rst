pandas.CategoricalIndex.fillna
==============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.fillna