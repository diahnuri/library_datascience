pandas.DataFrame.abs
====================

.. currentmodule:: pandas

.. automethod:: DataFrame.abs