pandas.DataFrame.set_index
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.set_index