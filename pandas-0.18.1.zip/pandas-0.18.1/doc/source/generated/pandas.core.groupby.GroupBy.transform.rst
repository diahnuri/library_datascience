pandas.core.groupby.GroupBy.transform
=====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.transform