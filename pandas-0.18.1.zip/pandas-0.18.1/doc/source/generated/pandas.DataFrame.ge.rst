pandas.DataFrame.ge
===================

.. currentmodule:: pandas

.. automethod:: DataFrame.ge