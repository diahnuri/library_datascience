pandas.DataFrame.plot.density
=============================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.density