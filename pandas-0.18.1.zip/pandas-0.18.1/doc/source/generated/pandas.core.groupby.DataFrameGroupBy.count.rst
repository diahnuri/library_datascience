pandas.core.groupby.DataFrameGroupBy.count
==========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.count