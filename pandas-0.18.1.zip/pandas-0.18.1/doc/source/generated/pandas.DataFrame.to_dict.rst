pandas.DataFrame.to_dict
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_dict