pandas.core.groupby.GroupBy.ohlc
================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.ohlc