pandas.DataFrame.plot.hist
==========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.hist