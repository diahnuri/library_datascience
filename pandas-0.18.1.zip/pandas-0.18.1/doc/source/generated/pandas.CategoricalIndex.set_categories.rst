pandas.CategoricalIndex.set_categories
======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.set_categories