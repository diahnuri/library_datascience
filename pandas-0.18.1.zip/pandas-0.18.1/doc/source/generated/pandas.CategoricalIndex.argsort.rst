pandas.CategoricalIndex.argsort
===============================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.argsort