pandas.DataFrame.resample
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.resample