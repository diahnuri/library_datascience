pandas.DataFrame.icol
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.icol