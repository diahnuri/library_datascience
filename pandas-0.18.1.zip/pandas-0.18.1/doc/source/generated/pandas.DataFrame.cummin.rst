pandas.DataFrame.cummin
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.cummin