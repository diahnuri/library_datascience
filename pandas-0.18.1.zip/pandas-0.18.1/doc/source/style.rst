.. _style:

.. currentmodule:: pandas

*****
Style
*****

.. raw:: html
   :file: html-styling.html
